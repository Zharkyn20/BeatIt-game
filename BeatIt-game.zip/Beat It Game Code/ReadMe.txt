Project name :	BeatIt-game
Developed by :	Zharkyn Askat kyzy

This is a game named as BeatIt in which you have to reduce the number of overall balls. In this you can create your own games and share them with your friends. It also has mp3 plyer by which you can play songs from it.
